// Archivo App.jsx con código React de Low Key Beats Lab
