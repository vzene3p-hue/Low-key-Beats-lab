// Configuración Tailwind
